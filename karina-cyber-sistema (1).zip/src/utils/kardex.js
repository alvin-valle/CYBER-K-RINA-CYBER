// Logica de Kardex por Costo Promedio Ponderado.
// Se reutiliza tanto en las rutas de la API (compras, POS) como en el
// script de datos de ejemplo, para que el calculo sea siempre consistente.

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

/**
 * Registra una ENTRADA de inventario (compra) y recalcula el costo
 * promedio ponderado del producto.
 */
function recordEntrada(db, { productId, qty, unitCost, reference, userId }) {
  if (qty <= 0) throw new Error('La cantidad de entrada debe ser mayor a cero');

  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
  if (!product) throw new Error('Producto no encontrado');

  const oldStock = product.stock;
  const oldAvg = product.avg_cost;
  const newStock = round2(oldStock + qty);
  const newAvg =
    newStock > 0 ? round2((oldStock * oldAvg + qty * unitCost) / newStock) : 0;

  db.prepare(
    `INSERT INTO kardex_movements (product_id, type, qty, unit_cost, balance_qty, balance_avg_cost, reference, user_id)
     VALUES (?, 'entrada', ?, ?, ?, ?, ?, ?)`
  ).run(productId, qty, unitCost, newStock, newAvg, reference || null, userId || null);

  db.prepare('UPDATE products SET stock = ?, avg_cost = ? WHERE id = ?').run(
    newStock,
    newAvg,
    productId
  );

  return { newStock, newAvg };
}

/**
 * Registra una SALIDA de inventario (venta / ajuste) al costo promedio
 * vigente. El costo promedio no cambia con una salida.
 */
function recordSalida(db, { productId, qty, reference, userId, allowNegative = false }) {
  if (qty <= 0) throw new Error('La cantidad de salida debe ser mayor a cero');

  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
  if (!product) throw new Error('Producto no encontrado');

  if (!allowNegative && product.stock < qty) {
    const err = new Error(
      `Stock insuficiente para "${product.name}" (disponible: ${product.stock} ${product.unit})`
    );
    err.code = 'STOCK_INSUFICIENTE';
    throw err;
  }

  const newStock = round2(product.stock - qty);
  const costBasis = product.avg_cost;

  db.prepare(
    `INSERT INTO kardex_movements (product_id, type, qty, unit_cost, balance_qty, balance_avg_cost, reference, user_id)
     VALUES (?, 'salida', ?, ?, ?, ?, ?, ?)`
  ).run(productId, qty, costBasis, newStock, product.avg_cost, reference || null, userId || null);

  db.prepare('UPDATE products SET stock = ? WHERE id = ?').run(newStock, productId);

  return { newStock, unitCost: costBasis };
}

module.exports = { recordEntrada, recordSalida, round2 };
