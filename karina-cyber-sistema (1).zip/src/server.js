require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');

const { run: seedDatabase } = require('./db/seed');
seedDatabase();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// ---------- API ----------
app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/users', require('./routes/users.routes'));
app.use('/api/dashboard', require('./routes/dashboard.routes'));
app.use('/api/inventory', require('./routes/inventory.routes'));
app.use('/api/pos', require('./routes/pos.routes'));
app.use('/api/printing', require('./routes/printing.routes'));
app.use('/api/recargas', require('./routes/recargas.routes'));
app.use('/api/finance', require('./routes/finance.routes'));
app.use('/api/security', require('./routes/security.routes'));
app.use('/api/reports', require('./routes/reports.routes'));

app.get('/api/health', (req, res) => res.json({ ok: true, name: 'K@rin@ cyber API' }));

// ---------- Frontend estatico ----------
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// Manejador de errores generico
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Ocurrio un error interno en el servidor.' });
});

app.listen(PORT, () => {
  console.log('');
  console.log('========================================================');
  console.log('  K@rin@ cyber - Sistema Administrativo Integral');
  console.log(`  Servidor activo en: http://localhost:${PORT}`);
  console.log('========================================================');
  console.log('');
});
