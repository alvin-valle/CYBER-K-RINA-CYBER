const path = require('path');
const fs = require('fs');
const { DatabaseSync } = require('node:sqlite');

const dataDir = path.join(__dirname, '..', '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.join(dataDir, 'karina_cyber.db');
const isNew = !fs.existsSync(dbPath);

// enableForeignKeyConstraints ya viene activado por defecto en node:sqlite,
// pero lo dejamos explicito por claridad.
const db = new DatabaseSync(dbPath, { enableForeignKeyConstraints: true });
db.exec('PRAGMA journal_mode = WAL;');

/**
 * Ejecuta una funcion dentro de una transaccion SQL (BEGIN/COMMIT/ROLLBACK).
 * node:sqlite no trae el helper db.transaction() de better-sqlite3, asi que
 * lo implementamos manualmente aqui y lo reutilizamos en las rutas.
 */
function runInTransaction(fn) {
  db.exec('BEGIN');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK');
    } catch (_) {
      /* ignorar error de rollback si la transaccion ya no estaba activa */
    }
    throw err;
  }
}

module.exports = { db, isNew, dbPath, runInTransaction };
