const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { db } = require('./connection');
const { recordEntrada, recordSalida, round2 } = require('../utils/kardex');

function run() {
  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  db.exec(schema);

  const userCount = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (userCount > 0) {
    console.log('La base de datos ya tiene datos. Se omite la carga inicial.');
    return;
  }

  console.log('Cargando datos iniciales de K@rin@ cyber ...');

  const insertUser = db.prepare(
    `INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)`
  );
  const hash = (pw) => bcrypt.hashSync(pw, 10);

  const users = [
    ['superadmin', hash('Karina2026*'), 'Erick Sequeira (Desarrollador)', 'superadmin'],
    ['admin', hash('Admin2026*'), 'Karina Ruiz (Propietaria)', 'admin'],
    ['cajero1', hash('Cajero2026*'), 'Melissa Gomez (Cajera)', 'cajero'],
    ['cajero2', hash('Cajero2026*'), 'Jonathan Ruiz (Cajero)', 'cajero'],
    ['auditor', hash('Auditor2026*'), 'Contador Externo (Solo lectura)', 'auditor'],
  ];
  const userIds = {};
  for (const u of users) {
    const info = insertUser.run(...u);
    userIds[u[0]] = info.lastInsertRowid;
  }

  const insertCategory = db.prepare('INSERT INTO categories (name) VALUES (?)');
  const categories = ['Papeleria', 'Insumos de Impresion', 'Tecnologia'];
  const catIds = {};
  for (const c of categories) catIds[c] = insertCategory.run(c).lastInsertRowid;

  const insertSupplier = db.prepare(
    'INSERT INTO suppliers (name, contact, phone) VALUES (?, ?, ?)'
  );
  const supIds = {};
  supIds['Distribuidora Internacional'] = insertSupplier.run(
    'Distribuidora Internacional',
    'Ventas Corporativas',
    '2277-4410'
  ).lastInsertRowid;
  supIds['Distribuidora Lizandro'] = insertSupplier.run(
    'Distribuidora Lizandro',
    'Wilber Lizandro',
    '8899-2231'
  ).lastInsertRowid;

  const insertProduct = db.prepare(
    `INSERT INTO products (sku, name, category_id, supplier_id, unit, stock, min_stock, avg_cost, price)
     VALUES (?, ?, ?, ?, ?, 0, ?, 0, ?)`
  );

  const productDefs = [
    ['RESMA-CARTA', 'Resma de papel carta 500h', 'Papeleria', 'Distribuidora Internacional', 'unidad', 40, 130, 15, 180],
    ['RESMA-OFICIO', 'Resma de papel oficio 500h', 'Papeleria', 'Distribuidora Internacional', 'unidad', 38, 140, 10, 190],
    ['TONER-HP85A', 'Toner HP 85A negro', 'Insumos de Impresion', 'Distribuidora Lizandro', 'unidad', 6, 850, 3, 1150],
    ['TINTA-COLOR', 'Cartucho de tinta color generico', 'Insumos de Impresion', 'Distribuidora Lizandro', 'unidad', 8, 320, 4, 480],
    ['ESPIRAL-7MM', 'Espiral plastico 7mm', 'Papeleria', 'Distribuidora Internacional', 'unidad', 120, 3.5, 40, 6],
    ['MICA-CARTA', 'Mica para anillado tamano carta', 'Papeleria', 'Distribuidora Internacional', 'unidad', 200, 1.2, 60, 2.5],
    ['LAPICERO-BIC', 'Lapicero Bic azul', 'Papeleria', 'Distribuidora Internacional', 'unidad', 90, 3, 30, 6],
    ['FOLDER-MANILA', 'Folder manila tamano carta', 'Papeleria', 'Distribuidora Internacional', 'unidad', 150, 2.2, 50, 4],
    ['USB-16GB', 'Memoria USB 16GB', 'Tecnologia', 'Distribuidora Lizandro', 'unidad', 30, 180, 5, 280],
    ['CUADERNO-100H', 'Cuaderno universitario 100 hojas', 'Papeleria', 'Distribuidora Internacional', 'unidad', 9, 35, 20, 55],
  ];

  const productIds = {};
  for (const [sku, name, cat, sup, unit, initialStock, initialCost, minStock, price] of productDefs) {
    const info = insertProduct.run(sku, name, catIds[cat], supIds[sup], unit, minStock, price);
    const id = info.lastInsertRowid;
    productIds[sku] = id;
    // Saldo inicial de inventario como una entrada de Kardex ("Inventario inicial")
    recordEntrada(db, {
      productId: id,
      qty: initialStock,
      unitCost: initialCost,
      reference: 'Inventario inicial',
      userId: userIds.superadmin,
    });
  }

  const insertCounter = db.prepare(
    'INSERT INTO printer_counters (machine_name, counter_bn, counter_color) VALUES (?, 0, 0)'
  );
  const machineIds = {};
  machineIds['Copiadora Ricoh MP2014'] = insertCounter.run('Copiadora Ricoh MP2014').lastInsertRowid;
  machineIds['Impresora HP LaserJet Pro'] = insertCounter.run('Impresora HP LaserJet Pro').lastInsertRowid;

  // ---------- Historial simulado de los ultimos 14 dias ----------
  const insertShift = db.prepare(
    `INSERT INTO cash_shifts (cashier_id, opened_at, closed_at, opening_amount, closing_amount_system, closing_amount_counted, difference, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insertSale = db.prepare(
    `INSERT INTO sales (shift_id, cashier_id, date, total, payment_method) VALUES (?, ?, ?, ?, ?)`
  );
  const insertSaleItem = db.prepare(
    `INSERT INTO sale_items (sale_id, product_id, qty, unit_price, unit_cost, subtotal) VALUES (?, ?, ?, ?, ?, ?)`
  );
  const insertPrinting = db.prepare(
    `INSERT INTO printing_services (shift_id, cashier_id, machine_id, date, service_type, qty, unit_price, subtotal, counter_start, counter_end, counter_delta, discrepancy)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insertRecarga = db.prepare(
    `INSERT INTO recargas (shift_id, cashier_id, date, telco, amount_gross, commission_pct, commission_amount, amount_net)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insertExpense = db.prepare(
    `INSERT INTO cash_expenses (shift_id, date, description, category, amount, user_id) VALUES (?, ?, ?, ?, ?, ?)`
  );
  const updateCounter = db.prepare(
    'UPDATE printer_counters SET counter_bn = ?, counter_color = ?, updated_at = ? WHERE id = ?'
  );

  const sellableSkus = [
    'RESMA-CARTA', 'RESMA-OFICIO', 'ESPIRAL-7MM', 'MICA-CARTA',
    'LAPICERO-BIC', 'FOLDER-MANILA', 'USB-16GB', 'CUADERNO-100H',
  ];
  const printingTypes = [
    { type: 'fotocopia_bn', price: 1.0, usesCounter: 'bn' },
    { type: 'fotocopia_color', price: 3.0, usesCounter: 'color' },
    { type: 'impresion_bn', price: 1.5, usesCounter: 'bn' },
    { type: 'impresion_color', price: 4.0, usesCounter: 'color' },
    { type: 'escaneo', price: 5.0, usesCounter: null },
    { type: 'anillado', price: 25.0, usesCounter: null },
  ];
  const telcos = ['Tigo', 'Claro'];
  const cashiers = [userIds.cajero1, userIds.cajero2];

  function rand(min, max) {
    return Math.random() * (max - min) + min;
  }
  function randInt(min, max) {
    return Math.floor(rand(min, max + 1));
  }
  function pick(arr) {
    return arr[randInt(0, arr.length - 1)];
  }

  const counterState = {
    'Copiadora Ricoh MP2014': { bn: 15000, color: 3200 },
    'Impresora HP LaserJet Pro': { bn: 8000, color: 1100 },
  };

  const today = new Date();
  const DAYS = 14;

  for (let d = DAYS - 1; d >= 0; d--) {
    const dayDate = new Date(today);
    dayDate.setDate(today.getDate() - d);
    const isToday = d === 0;

    const cashier = pick(cashiers);
    const openTime = new Date(dayDate);
    openTime.setHours(8, randInt(0, 15), 0, 0);
    const openingAmount = 500;

    const shiftInfo = insertShift.run(
      cashier,
      openTime.toISOString(),
      null,
      openingAmount,
      null,
      null,
      null,
      'abierto'
    );
    const shiftId = shiftInfo.lastInsertRowid;

    let systemCash = openingAmount;
    const numSales = randInt(4, 9);

    for (let s = 0; s < numSales; s++) {
      const saleTime = new Date(openTime);
      saleTime.setHours(8 + randInt(0, 9), randInt(0, 59), 0, 0);
      if (saleTime > new Date()) continue;

      const numItems = randInt(1, 3);
      const chosenSkus = new Set();
      while (chosenSkus.size < numItems) chosenSkus.add(pick(sellableSkus));

      let saleTotal = 0;
      const lines = [];
      for (const sku of chosenSkus) {
        const product = db.prepare('SELECT * FROM products WHERE id = ?').get(productIds[sku]);
        const maxQty = Math.min(3, Math.max(1, Math.floor(product.stock * 0.1)));
        const qty = randInt(1, Math.max(1, maxQty));
        if (qty <= 0 || product.stock < qty) continue;
        const subtotal = round2(qty * product.price);
        lines.push({ sku, qty, unitPrice: product.price, unitCost: product.avg_cost, subtotal });
        saleTotal += subtotal;
      }
      if (lines.length === 0) continue;

      const saleInfo = insertSale.run(
        shiftId,
        cashier,
        saleTime.toISOString(),
        round2(saleTotal),
        Math.random() < 0.8 ? 'efectivo' : 'tarjeta'
      );
      const saleId = saleInfo.lastInsertRowid;
      for (const line of lines) {
        insertSaleItem.run(
          saleId,
          productIds[line.sku],
          line.qty,
          line.unitPrice,
          line.unitCost,
          line.subtotal
        );
        recordSalida(db, {
          productId: productIds[line.sku],
          qty: line.qty,
          reference: `Venta #${saleId}`,
          userId: cashier,
        });
      }
      systemCash += saleTotal;
    }

    // Servicios de impresion con conciliacion de contadores
    const numPrints = randInt(3, 7);
    for (let p = 0; p < numPrints; p++) {
      const svc = pick(printingTypes);
      const machineName = pick(Object.keys(machineIds));
      const qty = randInt(1, 25);
      const subtotal = round2(qty * svc.price);
      const printTime = new Date(openTime);
      printTime.setHours(8 + randInt(0, 9), randInt(0, 59), 0, 0);
      if (printTime > new Date()) continue;

      let counterStart = null, counterEnd = null, counterDelta = null, discrepancy = null, machineId = null;
      if (svc.usesCounter) {
        machineId = machineIds[machineName];
        const key = svc.usesCounter;
        counterStart = counterState[machineName][key];
        // Casi siempre cuadra exacto; a veces hay una pequena discrepancia
        const noise = Math.random() < 0.12 ? pick([-2, -1, 1, 2]) : 0;
        counterEnd = counterStart + qty + noise;
        counterDelta = counterEnd - counterStart;
        discrepancy = round2(counterDelta - qty);
        counterState[machineName][key] = counterEnd;
      }

      insertPrinting.run(
        shiftId,
        cashier,
        machineId,
        printTime.toISOString(),
        svc.type,
        qty,
        svc.price,
        subtotal,
        counterStart,
        counterEnd,
        counterDelta,
        discrepancy
      );
      systemCash += subtotal;
    }

    // Recargas telefonicas
    const numRecargas = randInt(0, 3);
    for (let r = 0; r < numRecargas; r++) {
      const gross = pick([20, 30, 50, 100]);
      const commissionPct = 5;
      const commission = round2(gross * (commissionPct / 100));
      const net = round2(gross - commission);
      const rTime = new Date(openTime);
      rTime.setHours(8 + randInt(0, 9), randInt(0, 59), 0, 0);
      if (rTime > new Date()) continue;
      insertRecarga.run(
        shiftId,
        cashier,
        rTime.toISOString(),
        pick(telcos),
        gross,
        commissionPct,
        commission,
        net
      );
      systemCash += gross;
    }

    // Gasto operativo ocasional
    if (Math.random() < 0.35) {
      const expenseAmount = randInt(30, 150);
      insertExpense.run(
        shiftId,
        openTime.toISOString(),
        pick(['Compra de agua/cafe', 'Reparacion menor', 'Transporte a distribuidora', 'Papeleria de oficina']),
        'operativo',
        expenseAmount,
        cashier
      );
      systemCash -= expenseAmount;
    }

    if (!isToday) {
      const closeTime = new Date(dayDate);
      closeTime.setHours(18, randInt(0, 30), 0, 0);
      const diffNoise = Math.random() < 0.25 ? round2(pick([-15, -10, -5, 5, 10])) : 0;
      const counted = round2(systemCash + diffNoise);
      db.prepare(
        `UPDATE cash_shifts SET closed_at = ?, closing_amount_system = ?, closing_amount_counted = ?, difference = ?, status = 'cerrado' WHERE id = ?`
      ).run(closeTime.toISOString(), round2(systemCash), counted, round2(counted - systemCash), shiftId);
    }
    // El turno de "hoy" (d === 0) se deja ABIERTO intencionalmente para la demo en vivo.
  }

  for (const [name, id] of Object.entries(machineIds)) {
    const st = counterState[name];
    updateCounter.run(st.bn, st.color, new Date().toISOString(), id);
  }

  // Una compra recibida de ejemplo (para ver el flujo de orden de compra + Kardex)
  const poInfo = db
    .prepare(
      `INSERT INTO purchase_orders (supplier_id, status, invoice_number, iva_pct, created_at, received_at, user_id)
       VALUES (?, 'recibida', ?, 15, ?, ?, ?)`
    )
    .run(
      supIds['Distribuidora Internacional'],
      'FAC-00123',
      new Date(Date.now() - 5 * 86400000).toISOString(),
      new Date(Date.now() - 4 * 86400000).toISOString(),
      userIds.admin
    );
  const poId = poInfo.lastInsertRowid;
  db.prepare(
    'INSERT INTO purchase_order_items (po_id, product_id, qty, unit_cost) VALUES (?, ?, ?, ?)'
  ).run(poId, productIds['RESMA-CARTA'], 20, 132);
  recordEntrada(db, {
    productId: productIds['RESMA-CARTA'],
    qty: 20,
    unitCost: 132,
    reference: `Orden de compra #${poId} - Distribuidora Internacional`,
    userId: userIds.admin,
  });

  db.prepare(
    `INSERT INTO audit_log (user_id, action, entity, details) VALUES (?, 'seed', 'system', 'Carga inicial de datos de demostracion')`
  ).run(userIds.superadmin);

  console.log('Datos iniciales cargados correctamente.');
  console.log('');
  console.log('Usuarios de acceso (usuario / contrasena):');
  console.log('  superadmin / Karina2026*   (Superadministrador)');
  console.log('  admin      / Admin2026*    (Administrador / Propietaria)');
  console.log('  cajero1    / Cajero2026*   (Operador de caja)');
  console.log('  auditor    / Auditor2026*  (Invitado - solo lectura)');
}

module.exports = { run };

if (require.main === module) {
  run();
}
