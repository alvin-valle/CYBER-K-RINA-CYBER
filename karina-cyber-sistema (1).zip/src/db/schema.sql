-- ============================================================
-- K@rin@ cyber - Esquema de base de datos (SQLite)
-- Sistema Administrativo, Control de Inventario y Gestion de
-- Servicios de Impresion
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('superadmin','admin','cajero','auditor')),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS suppliers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  contact TEXT,
  phone TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sku TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  category_id INTEGER REFERENCES categories(id),
  supplier_id INTEGER REFERENCES suppliers(id),
  unit TEXT NOT NULL DEFAULT 'unidad',
  stock REAL NOT NULL DEFAULT 0,
  min_stock REAL NOT NULL DEFAULT 0,
  avg_cost REAL NOT NULL DEFAULT 0,
  price REAL NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Kardex: metodo de costo promedio ponderado
CREATE TABLE IF NOT EXISTS kardex_movements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id),
  date TEXT NOT NULL DEFAULT (datetime('now')),
  type TEXT NOT NULL CHECK (type IN ('entrada','salida','ajuste')),
  qty REAL NOT NULL,
  unit_cost REAL NOT NULL,
  balance_qty REAL NOT NULL,
  balance_avg_cost REAL NOT NULL,
  reference TEXT,
  user_id INTEGER REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS purchase_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  supplier_id INTEGER NOT NULL REFERENCES suppliers(id),
  status TEXT NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pendiente','recibida','cancelada')),
  invoice_number TEXT,
  iva_pct REAL NOT NULL DEFAULT 15,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  received_at TEXT,
  user_id INTEGER REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS purchase_order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  po_id INTEGER NOT NULL REFERENCES purchase_orders(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  qty REAL NOT NULL,
  unit_cost REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS cash_shifts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cashier_id INTEGER NOT NULL REFERENCES users(id),
  opened_at TEXT NOT NULL DEFAULT (datetime('now')),
  closed_at TEXT,
  opening_amount REAL NOT NULL DEFAULT 0,
  closing_amount_system REAL,
  closing_amount_counted REAL,
  difference REAL,
  status TEXT NOT NULL DEFAULT 'abierto' CHECK (status IN ('abierto','cerrado'))
);

CREATE TABLE IF NOT EXISTS sales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  shift_id INTEGER REFERENCES cash_shifts(id),
  cashier_id INTEGER NOT NULL REFERENCES users(id),
  date TEXT NOT NULL DEFAULT (datetime('now')),
  total REAL NOT NULL DEFAULT 0,
  payment_method TEXT NOT NULL DEFAULT 'efectivo'
);

CREATE TABLE IF NOT EXISTS sale_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_id INTEGER NOT NULL REFERENCES sales(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  qty REAL NOT NULL,
  unit_price REAL NOT NULL,
  unit_cost REAL NOT NULL,
  subtotal REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS printer_counters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  machine_name TEXT NOT NULL UNIQUE,
  counter_bn REAL NOT NULL DEFAULT 0,
  counter_color REAL NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS printing_services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  shift_id INTEGER REFERENCES cash_shifts(id),
  cashier_id INTEGER NOT NULL REFERENCES users(id),
  machine_id INTEGER REFERENCES printer_counters(id),
  date TEXT NOT NULL DEFAULT (datetime('now')),
  service_type TEXT NOT NULL CHECK (service_type IN ('fotocopia_bn','fotocopia_color','impresion_bn','impresion_color','escaneo','anillado')),
  qty REAL NOT NULL,
  unit_price REAL NOT NULL,
  subtotal REAL NOT NULL,
  counter_start REAL,
  counter_end REAL,
  counter_delta REAL,
  discrepancy REAL
);

CREATE TABLE IF NOT EXISTS recargas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  shift_id INTEGER REFERENCES cash_shifts(id),
  cashier_id INTEGER NOT NULL REFERENCES users(id),
  date TEXT NOT NULL DEFAULT (datetime('now')),
  telco TEXT NOT NULL,
  amount_gross REAL NOT NULL,
  commission_pct REAL NOT NULL,
  commission_amount REAL NOT NULL,
  amount_net REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS cash_expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  shift_id INTEGER NOT NULL REFERENCES cash_shifts(id),
  date TEXT NOT NULL DEFAULT (datetime('now')),
  description TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'operativo',
  amount REAL NOT NULL,
  user_id INTEGER REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS secure_deletions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL DEFAULT (datetime('now')),
  user_id INTEGER REFERENCES users(id),
  file_name TEXT NOT NULL,
  file_size INTEGER NOT NULL DEFAULT 0,
  passes INTEGER NOT NULL DEFAULT 3,
  method TEXT NOT NULL DEFAULT 'overwrite-random-3pass',
  status TEXT NOT NULL DEFAULT 'completado'
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL DEFAULT (datetime('now')),
  user_id INTEGER REFERENCES users(id),
  action TEXT NOT NULL,
  entity TEXT,
  entity_id INTEGER,
  details TEXT
);

CREATE INDEX IF NOT EXISTS idx_kardex_product ON kardex_movements(product_id);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(date);
CREATE INDEX IF NOT EXISTS idx_printing_date ON printing_services(date);
CREATE INDEX IF NOT EXISTS idx_recargas_date ON recargas(date);
