// Copia los assets de las librerias front-end (Bootstrap, Chart.js, Bootstrap Icons)
// desde node_modules hacia public/vendor para que el sistema funcione sin
// conexion a internet una vez instalado (npm install ya descargo todo).
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..', '..');
const vendorDir = path.join(root, 'public', 'vendor');

function copyFile(src, destRelative) {
  const dest = path.join(vendorDir, destRelative);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(src, dest);
}

function tryCopy(src, destRelative) {
  try {
    if (fs.existsSync(src)) {
      copyFile(src, destRelative);
      console.log('  vendor: copiado', destRelative);
    } else {
      console.warn('  vendor: no encontrado (omitido)', src);
    }
  } catch (err) {
    console.warn('  vendor: error copiando', destRelative, err.message);
  }
}

const nm = path.join(root, 'node_modules');

console.log('Preparando librerias locales en public/vendor ...');

tryCopy(path.join(nm, 'bootstrap', 'dist', 'css', 'bootstrap.min.css'), 'bootstrap/bootstrap.min.css');
tryCopy(path.join(nm, 'bootstrap', 'dist', 'css', 'bootstrap.min.css.map'), 'bootstrap/bootstrap.min.css.map');
tryCopy(path.join(nm, 'bootstrap', 'dist', 'js', 'bootstrap.bundle.min.js'), 'bootstrap/bootstrap.bundle.min.js');
tryCopy(path.join(nm, 'bootstrap', 'dist', 'js', 'bootstrap.bundle.min.js.map'), 'bootstrap/bootstrap.bundle.min.js.map');

tryCopy(path.join(nm, 'bootstrap-icons', 'font', 'bootstrap-icons.min.css'), 'bootstrap-icons/bootstrap-icons.min.css');
const biFontsDir = path.join(nm, 'bootstrap-icons', 'font', 'fonts');
if (fs.existsSync(biFontsDir)) {
  for (const f of fs.readdirSync(biFontsDir)) {
    tryCopy(path.join(biFontsDir, f), path.join('bootstrap-icons', 'fonts', f));
  }
}

tryCopy(path.join(nm, 'chart.js', 'dist', 'chart.umd.js'), 'chartjs/chart.umd.js');

console.log('Listo.');
