const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'karina-cyber-secreto-dev-cambiar-en-produccion';

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) {
    return res.status(401).json({ error: 'No autenticado. Inicia sesion nuevamente.' });
  }
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Sesion invalida o expirada. Inicia sesion nuevamente.' });
  }
}

// Roles jerarquicos segun el documento: superadmin > admin > cajero / auditor (lectura)
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'No autenticado.' });
    if (req.user.role === 'superadmin') return next(); // acceso total
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: 'No tienes permisos para realizar esta accion.' });
    }
    next();
  };
}

// Bloquea escritura para el rol de solo lectura (auditor/invitado)
function blockReadOnly(req, res, next) {
  if (req.user && req.user.role === 'auditor') {
    return res.status(403).json({ error: 'Tu perfil (Invitado/Auditor) tiene acceso de solo lectura.' });
  }
  next();
}

module.exports = { requireAuth, requireRole, blockReadOnly, JWT_SECRET };
