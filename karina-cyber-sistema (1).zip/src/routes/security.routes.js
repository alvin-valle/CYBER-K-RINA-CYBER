const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const { db } = require('../db/connection');
const { requireAuth, blockReadOnly } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

const TEMP_DIR = path.join(__dirname, '..', '..', 'data', 'temp_demo');
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, TEMP_DIR),
    filename: (req, file, cb) => {
      const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
      cb(null, `${Date.now()}_${safe}`);
    },
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
});

// Evita que rutas maliciosas escapen del directorio sandbox de archivos temporales
function safeTempPath(fileName) {
  const resolved = path.resolve(TEMP_DIR, fileName);
  if (!resolved.startsWith(TEMP_DIR)) return null;
  return resolved;
}

router.get('/temp-files', (req, res) => {
  const files = fs
    .readdirSync(TEMP_DIR)
    .filter((f) => !f.startsWith('.'))
    .map((f) => {
      const stat = fs.statSync(path.join(TEMP_DIR, f));
      return { name: f, size: stat.size, modified: stat.mtime };
    })
    .sort((a, b) => new Date(b.modified) - new Date(a.modified));
  res.json(files);
});

router.post('/temp-files', blockReadOnly, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Selecciona un archivo para simular.' });
  res.status(201).json({ name: req.file.filename, size: req.file.size });
});

// Borrado seguro: sobrescribe el archivo N veces con datos aleatorios antes de
// eliminarlo, para evitar la recuperacion forense del contenido original.
router.post('/secure-delete/:filename', blockReadOnly, (req, res) => {
  const filePath = safeTempPath(req.params.filename);
  if (!filePath || !fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'Archivo no encontrado.' });
  }

  const stat = fs.statSync(filePath);
  const size = stat.size;
  const passes = 3;

  try {
    const fd = fs.openSync(filePath, 'r+');
    for (let i = 0; i < passes; i++) {
      const buffer = crypto.randomBytes(size || 1);
      fs.writeSync(fd, buffer, 0, buffer.length, 0);
      fs.fsyncSync(fd);
    }
    fs.closeSync(fd);
    fs.unlinkSync(filePath);

    db.prepare(
      `INSERT INTO secure_deletions (user_id, file_name, file_size, passes, method, status)
       VALUES (?, ?, ?, ?, 'overwrite-random-3pass', 'completado')`
    ).run(req.user.id, req.params.filename, size, passes);

    res.json({ ok: true, passes });
  } catch (err) {
    db.prepare(
      `INSERT INTO secure_deletions (user_id, file_name, file_size, passes, method, status)
       VALUES (?, ?, ?, ?, 'overwrite-random-3pass', 'error')`
    ).run(req.user.id, req.params.filename, size, passes);
    res.status(500).json({ error: 'No se pudo completar el borrado seguro.' });
  }
});

router.get('/log', (req, res) => {
  const rows = db
    .prepare(
      `SELECT sd.*, u.full_name AS user_name
       FROM secure_deletions sd LEFT JOIN users u ON u.id = sd.user_id
       ORDER BY sd.date DESC LIMIT 100`
    )
    .all();
  res.json(rows);
});

module.exports = router;
