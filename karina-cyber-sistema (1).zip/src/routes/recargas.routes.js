const express = require('express');
const { db } = require('../db/connection');
const { requireAuth, blockReadOnly } = require('../middleware/auth');
const { round2 } = require('../utils/kardex');

const router = express.Router();
router.use(requireAuth);

function getOpenShift(cashierId) {
  return db
    .prepare(`SELECT * FROM cash_shifts WHERE cashier_id = ? AND status = 'abierto' ORDER BY id DESC LIMIT 1`)
    .get(cashierId);
}

router.get('/', (req, res) => {
  const { limit } = req.query;
  const rows = db
    .prepare(
      `SELECT r.*, u.full_name AS cashier_name
       FROM recargas r JOIN users u ON u.id = r.cashier_id
       ORDER BY r.date DESC LIMIT ?`
    )
    .all(Number(limit) || 100);
  res.json(rows);
});

router.post('/', blockReadOnly, (req, res) => {
  const { telco, amount_gross, commission_pct } = req.body || {};
  const gross = Number(amount_gross);
  const pct = commission_pct != null ? Number(commission_pct) : 5;
  if (!telco || !gross || gross <= 0) {
    return res.status(400).json({ error: 'Operadora y monto son requeridos.' });
  }
  const shift = getOpenShift(req.user.id);
  if (!shift) {
    return res.status(400).json({ error: 'Debes abrir un turno de caja antes de registrar recargas.' });
  }

  const commissionAmount = round2(gross * (pct / 100));
  const net = round2(gross - commissionAmount);

  const info = db
    .prepare(
      `INSERT INTO recargas (shift_id, cashier_id, telco, amount_gross, commission_pct, commission_amount, amount_net)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(shift.id, req.user.id, telco, gross, pct, commissionAmount, net);

  res.status(201).json({ id: info.lastInsertRowid, commissionAmount, net });
});

module.exports = router;
