const express = require('express');
const { db, runInTransaction } = require('../db/connection');
const { requireAuth, blockReadOnly } = require('../middleware/auth');
const { recordSalida, round2 } = require('../utils/kardex');

const router = express.Router();
router.use(requireAuth);

function getOpenShift(cashierId) {
  return db
    .prepare(`SELECT * FROM cash_shifts WHERE cashier_id = ? AND status = 'abierto' ORDER BY id DESC LIMIT 1`)
    .get(cashierId);
}

router.get('/sales', (req, res) => {
  const { date_from, date_to, limit } = req.query;
  let sql = `
    SELECT sa.*, u.full_name AS cashier_name
    FROM sales sa JOIN users u ON u.id = sa.cashier_id
    WHERE 1=1`;
  const params = [];
  if (date_from) {
    sql += ' AND date >= ?';
    params.push(date_from);
  }
  if (date_to) {
    sql += ' AND date <= ?';
    params.push(date_to);
  }
  sql += ' ORDER BY sa.date DESC LIMIT ?';
  params.push(Number(limit) || 100);
  res.json(db.prepare(sql).all(...params));
});

router.get('/sales/:id', (req, res) => {
  const sale = db
    .prepare(
      `SELECT sa.*, u.full_name AS cashier_name FROM sales sa JOIN users u ON u.id = sa.cashier_id WHERE sa.id = ?`
    )
    .get(req.params.id);
  if (!sale) return res.status(404).json({ error: 'Venta no encontrada.' });
  const items = db
    .prepare(
      `SELECT si.*, p.name AS product_name, p.sku FROM sale_items si JOIN products p ON p.id = si.product_id WHERE si.sale_id = ?`
    )
    .all(req.params.id);
  res.json({ ...sale, items });
});

router.post('/sales', blockReadOnly, (req, res) => {
  const { items, payment_method } = req.body || {};
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Agrega al menos un producto al carrito.' });
  }

  const shift = getOpenShift(req.user.id);
  if (!shift) {
    return res.status(400).json({ error: 'Debes abrir un turno de caja antes de registrar ventas.' });
  }

  try {
    const result = runInTransaction(() => {
      let total = 0;
      const lines = [];
      for (const it of items) {
        const product = db.prepare('SELECT * FROM products WHERE id = ?').get(it.product_id);
        if (!product || !product.active) throw new Error('Producto no disponible.');
        const qty = Number(it.qty);
        if (!qty || qty <= 0) throw new Error('Cantidad invalida.');
        const unitPrice = product.price;
        const subtotal = round2(qty * unitPrice);
        lines.push({ product, qty, unitPrice, subtotal });
        total += subtotal;
      }

      const saleInfo = db
        .prepare(
          `INSERT INTO sales (shift_id, cashier_id, total, payment_method) VALUES (?, ?, ?, ?)`
        )
        .run(shift.id, req.user.id, round2(total), payment_method || 'efectivo');
      const saleId = saleInfo.lastInsertRowid;

      for (const line of lines) {
        const { newStock, unitCost } = recordSalida(db, {
          productId: line.product.id,
          qty: line.qty,
          reference: `Venta #${saleId}`,
          userId: req.user.id,
        });
        db.prepare(
          `INSERT INTO sale_items (sale_id, product_id, qty, unit_price, unit_cost, subtotal) VALUES (?, ?, ?, ?, ?, ?)`
        ).run(saleId, line.product.id, line.qty, line.unitPrice, unitCost, line.subtotal);
        void newStock;
      }

      return { saleId, total: round2(total) };
    });

    const items_out = db
      .prepare(
        `SELECT si.*, p.name AS product_name, p.sku FROM sale_items si JOIN products p ON p.id = si.product_id WHERE si.sale_id = ?`
      )
      .all(result.saleId);
    res.status(201).json({ id: result.saleId, total: result.total, items: items_out });
  } catch (err) {
    const status = err.code === 'STOCK_INSUFICIENTE' ? 409 : 400;
    res.status(status).json({ error: err.message });
  }
});

module.exports = router;
