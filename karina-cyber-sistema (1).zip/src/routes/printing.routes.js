const express = require('express');
const { db } = require('../db/connection');
const { requireAuth, blockReadOnly } = require('../middleware/auth');
const { round2 } = require('../utils/kardex');

const router = express.Router();
router.use(requireAuth);

const PRICES = {
  fotocopia_bn: 1.0,
  fotocopia_color: 3.0,
  impresion_bn: 1.5,
  impresion_color: 4.0,
  escaneo: 5.0,
  anillado: 25.0,
};
const LABELS = {
  fotocopia_bn: 'Fotocopia B/N',
  fotocopia_color: 'Fotocopia Color',
  impresion_bn: 'Impresion B/N',
  impresion_color: 'Impresion Color',
  escaneo: 'Escaneo / Digitalizacion',
  anillado: 'Anillado',
};
const USES_COUNTER = {
  fotocopia_bn: 'counter_bn',
  fotocopia_color: 'counter_color',
  impresion_bn: 'counter_bn',
  impresion_color: 'counter_color',
};

function getOpenShift(cashierId) {
  return db
    .prepare(`SELECT * FROM cash_shifts WHERE cashier_id = ? AND status = 'abierto' ORDER BY id DESC LIMIT 1`)
    .get(cashierId);
}

router.get('/catalog', (req, res) => {
  res.json(Object.keys(PRICES).map((type) => ({ type, label: LABELS[type], price: PRICES[type] })));
});

router.get('/printer-counters', (req, res) => {
  res.json(db.prepare('SELECT * FROM printer_counters ORDER BY machine_name').all());
});

router.get('/printing-services', (req, res) => {
  const { limit, only_discrepancies } = req.query;
  let sql = `
    SELECT ps.*, u.full_name AS cashier_name, pc.machine_name
    FROM printing_services ps
    JOIN users u ON u.id = ps.cashier_id
    LEFT JOIN printer_counters pc ON pc.id = ps.machine_id
    WHERE 1=1`;
  if (only_discrepancies === '1') {
    sql += ' AND ps.discrepancy IS NOT NULL AND ps.discrepancy != 0';
  }
  sql += ' ORDER BY ps.date DESC LIMIT ?';
  res.json(db.prepare(sql).all(Number(limit) || 100));
});

router.post('/printing-services', blockReadOnly, (req, res) => {
  const { service_type, machine_id, qty, counter_end } = req.body || {};
  if (!service_type || !PRICES[service_type]) {
    return res.status(400).json({ error: 'Tipo de servicio invalido.' });
  }
  const qtyNum = Number(qty);
  if (!qtyNum || qtyNum <= 0) {
    return res.status(400).json({ error: 'La cantidad debe ser mayor a cero.' });
  }

  const shift = getOpenShift(req.user.id);
  if (!shift) {
    return res.status(400).json({ error: 'Debes abrir un turno de caja antes de registrar servicios.' });
  }

  const unitPrice = PRICES[service_type];
  const subtotal = round2(qtyNum * unitPrice);
  const counterField = USES_COUNTER[service_type];

  let counterStart = null, counterEnd = null, counterDelta = null, discrepancy = null;

  if (counterField) {
    if (!machine_id) {
      return res.status(400).json({ error: 'Selecciona la maquina para conciliar el contador fisico.' });
    }
    const machine = db.prepare('SELECT * FROM printer_counters WHERE id = ?').get(machine_id);
    if (!machine) return res.status(404).json({ error: 'Maquina no encontrada.' });

    counterStart = machine[counterField];
    counterEnd = counter_end != null && counter_end !== '' ? Number(counter_end) : counterStart + qtyNum;
    counterDelta = round2(counterEnd - counterStart);
    discrepancy = round2(counterDelta - qtyNum);

    db.prepare(`UPDATE printer_counters SET ${counterField} = ?, updated_at = datetime('now') WHERE id = ?`).run(
      counterEnd,
      machine_id
    );
  }

  const info = db
    .prepare(
      `INSERT INTO printing_services (shift_id, cashier_id, machine_id, service_type, qty, unit_price, subtotal, counter_start, counter_end, counter_delta, discrepancy)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      shift.id,
      req.user.id,
      machine_id || null,
      service_type,
      qtyNum,
      unitPrice,
      subtotal,
      counterStart,
      counterEnd,
      counterDelta,
      discrepancy
    );

  res.status(201).json({
    id: info.lastInsertRowid,
    subtotal,
    counterStart,
    counterEnd,
    discrepancy,
    hasDiscrepancy: discrepancy != null && discrepancy !== 0,
  });
});

module.exports = router;
