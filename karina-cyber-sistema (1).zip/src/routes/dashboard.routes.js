const express = require('express');
const { db } = require('../db/connection');
const { requireAuth } = require('../middleware/auth');
const { round2 } = require('../utils/kardex');

const router = express.Router();
router.use(requireAuth);

router.get('/summary', (req, res) => {
  const today = db.prepare("SELECT date('now') d").get().d;

  const salesToday =
    db
      .prepare(`SELECT COALESCE(SUM(total),0) t, COUNT(*) c FROM sales WHERE date(date) = ?`)
      .get(today) || { t: 0, c: 0 };
  const printingToday =
    db
      .prepare(`SELECT COALESCE(SUM(subtotal),0) t, COUNT(*) c FROM printing_services WHERE date(date) = ?`)
      .get(today) || { t: 0, c: 0 };
  const recargasToday =
    db
      .prepare(`SELECT COALESCE(SUM(amount_gross),0) t, COUNT(*) c FROM recargas WHERE date(date) = ?`)
      .get(today) || { t: 0, c: 0 };
  const expensesToday =
    db.prepare(`SELECT COALESCE(SUM(amount),0) t FROM cash_expenses WHERE date(date) = ?`).get(today) || {
      t: 0,
    };

  const ingresosHoy = round2(
    (salesToday.t || 0) + (printingToday.t || 0) + (recargasToday.t || 0)
  );

  const lowStock = db
    .prepare(
      `SELECT id, sku, name, stock, min_stock, unit FROM products WHERE active = 1 AND stock <= min_stock ORDER BY (stock - min_stock) ASC LIMIT 10`
    )
    .all();

  const openShifts = db
    .prepare(
      `SELECT cs.id, cs.cashier_id, u.full_name AS cashier_name, cs.opened_at, cs.opening_amount
       FROM cash_shifts cs JOIN users u ON u.id = cs.cashier_id WHERE cs.status = 'abierto'`
    )
    .all();

  // Ingresos diarios (ultimos 7 dias) para grafico de linea/barras
  const dailyRevenue = db
    .prepare(
      `SELECT date(date) d, SUM(total) t FROM sales WHERE date >= date('now','-6 days') GROUP BY date(date)`
    )
    .all();
  const dailyPrinting = db
    .prepare(
      `SELECT date(date) d, SUM(subtotal) t FROM printing_services WHERE date >= date('now','-6 days') GROUP BY date(date)`
    )
    .all();
  const dailyRecargas = db
    .prepare(
      `SELECT date(date) d, SUM(amount_gross) t FROM recargas WHERE date >= date('now','-6 days') GROUP BY date(date)`
    )
    .all();

  const revenueMap = {};
  for (let i = 6; i >= 0; i--) {
    const d = db.prepare(`SELECT date('now', ?) d`).get(`-${i} days`).d;
    revenueMap[d] = 0;
  }
  for (const row of [...dailyRevenue, ...dailyPrinting, ...dailyRecargas]) {
    revenueMap[row.d] = round2((revenueMap[row.d] || 0) + (row.t || 0));
  }
  const dailyRevenueSeries = Object.entries(revenueMap).map(([date, total]) => ({ date, total }));

  // Ingresos por categoria (ultimos 7 dias): productos por categoria + servicios + recargas
  const productCategoryRevenue = db
    .prepare(
      `SELECT c.name AS category, SUM(si.subtotal) t
       FROM sale_items si
       JOIN products p ON p.id = si.product_id
       LEFT JOIN categories c ON c.id = p.category_id
       JOIN sales sa ON sa.id = si.sale_id
       WHERE sa.date >= datetime('now','-6 days')
       GROUP BY c.name`
    )
    .all();
  const printingRevenue7d =
    db
      .prepare(`SELECT COALESCE(SUM(subtotal),0) t FROM printing_services WHERE date >= datetime('now','-6 days')`)
      .get().t || 0;
  const recargasRevenue7d =
    db
      .prepare(`SELECT COALESCE(SUM(amount_gross),0) t FROM recargas WHERE date >= datetime('now','-6 days')`)
      .get().t || 0;

  const categoryBreakdown = [
    ...productCategoryRevenue.map((r) => ({ label: r.category || 'Sin categoria', total: round2(r.t) })),
    { label: 'Servicios de impresion', total: round2(printingRevenue7d) },
    { label: 'Recargas telefonicas', total: round2(recargasRevenue7d) },
  ].filter((r) => r.total > 0);

  // Curva de demanda por franja horaria (ultimos 14 dias) - ventas + impresiones + recargas
  const hourlyRaw = db
    .prepare(
      `SELECT strftime('%H', date) h, COUNT(*) c FROM (
         SELECT date FROM sales WHERE date >= datetime('now','-13 days')
         UNION ALL
         SELECT date FROM printing_services WHERE date >= datetime('now','-13 days')
         UNION ALL
         SELECT date FROM recargas WHERE date >= datetime('now','-13 days')
       ) GROUP BY h ORDER BY h`
    )
    .all();
  const hourlyMap = {};
  for (let h = 7; h <= 19; h++) hourlyMap[String(h).padStart(2, '0')] = 0;
  for (const row of hourlyRaw) {
    if (hourlyMap[row.h] !== undefined) hourlyMap[row.h] = row.c;
  }
  const hourlyDemand = Object.entries(hourlyMap).map(([hour, count]) => ({ hour: `${hour}:00`, count }));

  // Top 5 productos mas vendidos (ultimos 30 dias)
  const topProducts = db
    .prepare(
      `SELECT p.name, p.sku, SUM(si.qty) qty, SUM(si.subtotal) total
       FROM sale_items si JOIN products p ON p.id = si.product_id
       JOIN sales sa ON sa.id = si.sale_id
       WHERE sa.date >= datetime('now','-29 days')
       GROUP BY p.id ORDER BY total DESC LIMIT 5`
    )
    .all();

  const discrepanciesCount =
    db
      .prepare(
        `SELECT COUNT(*) c FROM printing_services WHERE discrepancy IS NOT NULL AND discrepancy != 0 AND date >= datetime('now','-6 days')`
      )
      .get().c || 0;

  const inventoryValue =
    db.prepare(`SELECT COALESCE(SUM(stock * avg_cost),0) v FROM products WHERE active = 1`).get().v || 0;

  res.json({
    ingresosHoy,
    ventasHoy: { total: round2(salesToday.t || 0), count: salesToday.c || 0 },
    impresionesHoy: { total: round2(printingToday.t || 0), count: printingToday.c || 0 },
    recargasHoy: { total: round2(recargasToday.t || 0), count: recargasToday.c || 0 },
    gastosHoy: round2(expensesToday.t || 0),
    lowStock,
    lowStockCount: lowStock.length,
    openShifts,
    dailyRevenueSeries,
    categoryBreakdown,
    hourlyDemand,
    topProducts,
    discrepanciesCount,
    inventoryValue: round2(inventoryValue),
  });
});

module.exports = router;
