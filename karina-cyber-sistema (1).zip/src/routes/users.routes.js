const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../db/connection');
const { requireAuth, requireRole, blockReadOnly } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

router.get('/', requireRole('admin'), (req, res) => {
  const rows = db
    .prepare('SELECT id, username, full_name, role, active, created_at FROM users ORDER BY full_name')
    .all();
  res.json(rows);
});

router.post('/', requireRole('admin'), blockReadOnly, (req, res) => {
  const { username, password, full_name, role } = req.body || {};
  const validRoles = ['superadmin', 'admin', 'cajero', 'auditor'];
  if (!username || !password || !full_name || !validRoles.includes(role)) {
    return res.status(400).json({ error: 'Todos los campos son requeridos y el rol debe ser valido.' });
  }
  // Solo un superadmin puede crear otro superadmin
  if (role === 'superadmin' && req.user.role !== 'superadmin') {
    return res.status(403).json({ error: 'Solo un Superadministrador puede crear otro Superadministrador.' });
  }
  try {
    const hash = bcrypt.hashSync(password, 10);
    const info = db
      .prepare('INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)')
      .run(username.trim(), hash, full_name.trim(), role);
    res.status(201).json({ id: info.lastInsertRowid });
  } catch (err) {
    res.status(400).json({ error: 'El nombre de usuario ya existe.' });
  }
});

router.patch('/:id', requireRole('admin'), blockReadOnly, (req, res) => {
  const { active, role, full_name } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Usuario no encontrado.' });
  if (user.role === 'superadmin' && req.user.role !== 'superadmin') {
    return res.status(403).json({ error: 'No puedes modificar a un Superadministrador.' });
  }
  db.prepare('UPDATE users SET active = ?, role = ?, full_name = ? WHERE id = ?').run(
    active != null ? Number(active) : user.active,
    role || user.role,
    full_name || user.full_name,
    req.params.id
  );
  res.json({ ok: true });
});

module.exports = router;
