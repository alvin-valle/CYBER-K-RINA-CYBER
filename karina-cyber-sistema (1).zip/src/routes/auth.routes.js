const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../db/connection');
const { requireAuth, JWT_SECRET } = require('../middleware/auth');

const router = express.Router();

const ROLE_LABELS = {
  superadmin: 'Superadministrador',
  admin: 'Administrador',
  cajero: 'Operador / Cajero',
  auditor: 'Invitado / Auditor',
};

router.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: 'Usuario y contrasena son requeridos.' });
  }

  const user = db
    .prepare('SELECT * FROM users WHERE username = ? COLLATE NOCASE')
    .get(username.trim());

  if (!user || !user.active) {
    return res.status(401).json({ error: 'Usuario o contrasena incorrectos.' });
  }

  const ok = bcrypt.compareSync(password, user.password_hash);
  if (!ok) {
    return res.status(401).json({ error: 'Usuario o contrasena incorrectos.' });
  }

  const payload = {
    id: user.id,
    username: user.username,
    full_name: user.full_name,
    role: user.role,
  };
  const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '12h' });

  db.prepare(
    `INSERT INTO audit_log (user_id, action, entity, details) VALUES (?, 'login', 'auth', ?)`
  ).run(user.id, `Inicio de sesion desde la app web`);

  res.json({
    token,
    user: { ...payload, role_label: ROLE_LABELS[user.role] || user.role },
  });
});

router.get('/me', requireAuth, (req, res) => {
  res.json({ user: { ...req.user, role_label: ROLE_LABELS[req.user.role] || req.user.role } });
});

module.exports = router;
