const express = require('express');
const { db, runInTransaction } = require('../db/connection');
const { requireAuth, requireRole, blockReadOnly } = require('../middleware/auth');
const { recordEntrada } = require('../utils/kardex');

const router = express.Router();
router.use(requireAuth);

// ---------- Categorias ----------
router.get('/categories', (req, res) => {
  res.json(db.prepare('SELECT * FROM categories ORDER BY name').all());
});

router.post('/categories', requireRole('admin'), blockReadOnly, (req, res) => {
  const { name } = req.body || {};
  if (!name || !name.trim()) return res.status(400).json({ error: 'El nombre es requerido.' });
  try {
    const info = db.prepare('INSERT INTO categories (name) VALUES (?)').run(name.trim());
    res.status(201).json({ id: info.lastInsertRowid, name: name.trim() });
  } catch (err) {
    res.status(400).json({ error: 'Ya existe una categoria con ese nombre.' });
  }
});

// ---------- Proveedores ----------
router.get('/suppliers', (req, res) => {
  res.json(db.prepare('SELECT * FROM suppliers ORDER BY name').all());
});

router.post('/suppliers', requireRole('admin'), blockReadOnly, (req, res) => {
  const { name, contact, phone } = req.body || {};
  if (!name || !name.trim()) return res.status(400).json({ error: 'El nombre es requerido.' });
  const info = db
    .prepare('INSERT INTO suppliers (name, contact, phone) VALUES (?, ?, ?)')
    .run(name.trim(), contact || null, phone || null);
  res.status(201).json({ id: info.lastInsertRowid });
});

// ---------- Productos ----------
router.get('/products', (req, res) => {
  const { q, low_stock } = req.query;
  let sql = `
    SELECT p.*, c.name AS category_name, s.name AS supplier_name,
           (p.stock * p.avg_cost) AS inventory_value,
           CASE WHEN p.stock <= p.min_stock THEN 1 ELSE 0 END AS is_low_stock
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN suppliers s ON s.id = p.supplier_id
    WHERE p.active = 1
  `;
  const params = [];
  if (q) {
    sql += ' AND (p.name LIKE ? OR p.sku LIKE ?)';
    params.push(`%${q}%`, `%${q}%`);
  }
  if (low_stock === '1') {
    sql += ' AND p.stock <= p.min_stock';
  }
  sql += ' ORDER BY p.name';
  res.json(db.prepare(sql).all(...params));
});

router.post('/products', requireRole('admin'), blockReadOnly, (req, res) => {
  const { sku, name, category_id, supplier_id, unit, min_stock, price, initial_stock, initial_cost } =
    req.body || {};
  if (!sku || !name || price == null) {
    return res.status(400).json({ error: 'SKU, nombre y precio son requeridos.' });
  }
  try {
    const info = db
      .prepare(
        `INSERT INTO products (sku, name, category_id, supplier_id, unit, min_stock, price)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        sku.trim(),
        name.trim(),
        category_id || null,
        supplier_id || null,
        unit || 'unidad',
        Number(min_stock) || 0,
        Number(price)
      );
    const productId = info.lastInsertRowid;

    if (Number(initial_stock) > 0) {
      recordEntrada(db, {
        productId,
        qty: Number(initial_stock),
        unitCost: Number(initial_cost) || 0,
        reference: 'Inventario inicial (registro manual)',
        userId: req.user.id,
      });
    }
    res.status(201).json({ id: productId });
  } catch (err) {
    res.status(400).json({ error: 'No se pudo crear el producto. Verifica que el SKU no exista.' });
  }
});

router.put('/products/:id', requireRole('admin'), blockReadOnly, (req, res) => {
  const { name, category_id, supplier_id, unit, min_stock, price, active } = req.body || {};
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) return res.status(404).json({ error: 'Producto no encontrado.' });

  db.prepare(
    `UPDATE products SET name = ?, category_id = ?, supplier_id = ?, unit = ?, min_stock = ?, price = ?, active = ?
     WHERE id = ?`
  ).run(
    name ?? product.name,
    category_id ?? product.category_id,
    supplier_id ?? product.supplier_id,
    unit ?? product.unit,
    min_stock != null ? Number(min_stock) : product.min_stock,
    price != null ? Number(price) : product.price,
    active != null ? Number(active) : product.active,
    req.params.id
  );
  res.json({ ok: true });
});

router.get('/products/:id/kardex', (req, res) => {
  const rows = db
    .prepare(
      `SELECT k.*, u.full_name AS user_name
       FROM kardex_movements k
       LEFT JOIN users u ON u.id = k.user_id
       WHERE k.product_id = ?
       ORDER BY k.date DESC, k.id DESC
       LIMIT 200`
    )
    .all(req.params.id);
  res.json(rows);
});

// ---------- Ordenes de compra ----------
router.get('/purchase-orders', (req, res) => {
  const rows = db
    .prepare(
      `SELECT po.*, s.name AS supplier_name, u.full_name AS user_name,
              (SELECT COALESCE(SUM(qty * unit_cost), 0) FROM purchase_order_items WHERE po_id = po.id) AS subtotal
       FROM purchase_orders po
       LEFT JOIN suppliers s ON s.id = po.supplier_id
       LEFT JOIN users u ON u.id = po.user_id
       ORDER BY po.created_at DESC`
    )
    .all();
  res.json(rows);
});

router.get('/purchase-orders/:id', (req, res) => {
  const po = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id);
  if (!po) return res.status(404).json({ error: 'Orden no encontrada.' });
  const items = db
    .prepare(
      `SELECT poi.*, p.name AS product_name, p.sku
       FROM purchase_order_items poi JOIN products p ON p.id = poi.product_id
       WHERE poi.po_id = ?`
    )
    .all(req.params.id);
  res.json({ ...po, items });
});

router.post('/purchase-orders', requireRole('admin'), blockReadOnly, (req, res) => {
  const { supplier_id, invoice_number, iva_pct, items } = req.body || {};
  if (!supplier_id || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Proveedor y al menos un producto son requeridos.' });
  }
  const poId = runInTransaction(() => {
    const info = db
      .prepare(
        `INSERT INTO purchase_orders (supplier_id, status, invoice_number, iva_pct, user_id)
         VALUES (?, 'pendiente', ?, ?, ?)`
      )
      .run(supplier_id, invoice_number || null, iva_pct != null ? Number(iva_pct) : 15, req.user.id);
    const poId = info.lastInsertRowid;
    const insertItem = db.prepare(
      'INSERT INTO purchase_order_items (po_id, product_id, qty, unit_cost) VALUES (?, ?, ?, ?)'
    );
    for (const it of items) {
      if (!it.product_id || !it.qty || it.unit_cost == null) continue;
      insertItem.run(poId, it.product_id, Number(it.qty), Number(it.unit_cost));
    }
    return poId;
  });
  res.status(201).json({ id: poId });
});

router.post('/purchase-orders/:id/receive', requireRole('admin'), blockReadOnly, (req, res) => {
  const po = db.prepare('SELECT * FROM purchase_orders WHERE id = ?').get(req.params.id);
  if (!po) return res.status(404).json({ error: 'Orden no encontrada.' });
  if (po.status !== 'pendiente') {
    return res.status(400).json({ error: 'Esta orden ya fue procesada.' });
  }
  const items = db
    .prepare('SELECT * FROM purchase_order_items WHERE po_id = ?')
    .all(req.params.id);

  runInTransaction(() => {
    for (const it of items) {
      recordEntrada(db, {
        productId: it.product_id,
        qty: it.qty,
        unitCost: it.unit_cost,
        reference: `Orden de compra #${po.id}`,
        userId: req.user.id,
      });
    }
    db.prepare(
      `UPDATE purchase_orders SET status = 'recibida', received_at = datetime('now') WHERE id = ?`
    ).run(po.id);
  });
  res.json({ ok: true });
});

module.exports = router;
