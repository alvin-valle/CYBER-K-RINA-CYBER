const express = require('express');
const { db } = require('../db/connection');
const { requireAuth } = require('../middleware/auth');
const { round2 } = require('../utils/kardex');

const router = express.Router();
router.use(requireAuth);

function dateRange(req) {
  const from = req.query.from || db.prepare(`SELECT date('now','-29 days') d`).get().d;
  const to = req.query.to || db.prepare(`SELECT date('now') d`).get().d;
  return { from, to };
}

router.get('/margins', (req, res) => {
  const { from, to } = dateRange(req);
  const rows = db
    .prepare(
      `SELECT p.id, p.sku, p.name, c.name AS category,
              SUM(si.qty) AS qty_sold,
              SUM(si.subtotal) AS revenue,
              SUM(si.qty * si.unit_cost) AS cost
       FROM sale_items si
       JOIN products p ON p.id = si.product_id
       LEFT JOIN categories c ON c.id = p.category_id
       JOIN sales sa ON sa.id = si.sale_id
       WHERE date(sa.date) BETWEEN ? AND ?
       GROUP BY p.id
       ORDER BY revenue DESC`
    )
    .all(from, to);

  const withMargin = rows.map((r) => {
    const margin = round2(r.revenue - r.cost);
    const marginPct = r.revenue > 0 ? round2((margin / r.revenue) * 100) : 0;
    return { ...r, revenue: round2(r.revenue), cost: round2(r.cost), margin, marginPct };
  });

  const totals = withMargin.reduce(
    (acc, r) => ({
      revenue: round2(acc.revenue + r.revenue),
      cost: round2(acc.cost + r.cost),
      margin: round2(acc.margin + r.margin),
    }),
    { revenue: 0, cost: 0, margin: 0 }
  );

  res.json({ from, to, products: withMargin, totals });
});

router.get('/sales-summary', (req, res) => {
  const { from, to } = dateRange(req);
  const sales = db
    .prepare(
      `SELECT date(date) d, COUNT(*) c, SUM(total) t FROM sales WHERE date(date) BETWEEN ? AND ? GROUP BY date(date) ORDER BY d`
    )
    .all(from, to);
  const printing = db
    .prepare(
      `SELECT date(date) d, COUNT(*) c, SUM(subtotal) t FROM printing_services WHERE date(date) BETWEEN ? AND ? GROUP BY date(date) ORDER BY d`
    )
    .all(from, to);
  const recargas = db
    .prepare(
      `SELECT date(date) d, COUNT(*) c, SUM(amount_gross) t, SUM(commission_amount) com FROM recargas WHERE date(date) BETWEEN ? AND ? GROUP BY date(date) ORDER BY d`
    )
    .all(from, to);
  const expenses = db
    .prepare(
      `SELECT date(date) d, SUM(amount) t FROM cash_expenses WHERE date(date) BETWEEN ? AND ? GROUP BY date(date) ORDER BY d`
    )
    .all(from, to);
  res.json({ from, to, sales, printing, recargas, expenses });
});

router.get('/export/sales.csv', (req, res) => {
  const { from, to } = dateRange(req);
  const rows = db
    .prepare(
      `SELECT sa.id, sa.date, u.full_name AS cajero, sa.payment_method, sa.total
       FROM sales sa JOIN users u ON u.id = sa.cashier_id
       WHERE date(sa.date) BETWEEN ? AND ? ORDER BY sa.date`
    )
    .all(from, to);

  const header = 'ID,Fecha,Cajero,Metodo de pago,Total\n';
  const body = rows
    .map((r) => [r.id, r.date, `"${r.cajero}"`, r.payment_method, r.total].join(','))
    .join('\n');

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="ventas_${from}_a_${to}.csv"`);
  res.send(header + body);
});

module.exports = router;
