const express = require('express');
const { db } = require('../db/connection');
const { requireAuth, requireRole, blockReadOnly } = require('../middleware/auth');
const { round2 } = require('../utils/kardex');

const router = express.Router();
router.use(requireAuth);

function computeShiftBreakdown(shiftId) {
  const shift = db.prepare('SELECT * FROM cash_shifts WHERE id = ?').get(shiftId);
  if (!shift) return null;

  const cashSales =
    db
      .prepare(
        `SELECT COALESCE(SUM(total),0) t FROM sales WHERE shift_id = ? AND payment_method = 'efectivo'`
      )
      .get(shiftId).t || 0;
  const cardSales =
    db
      .prepare(
        `SELECT COALESCE(SUM(total),0) t FROM sales WHERE shift_id = ? AND payment_method != 'efectivo'`
      )
      .get(shiftId).t || 0;
  const printingTotal =
    db.prepare(`SELECT COALESCE(SUM(subtotal),0) t FROM printing_services WHERE shift_id = ?`).get(shiftId)
      .t || 0;
  const recargasGross =
    db.prepare(`SELECT COALESCE(SUM(amount_gross),0) t FROM recargas WHERE shift_id = ?`).get(shiftId).t ||
    0;
  const expenses =
    db.prepare(`SELECT COALESCE(SUM(amount),0) t FROM cash_expenses WHERE shift_id = ?`).get(shiftId).t ||
    0;

  const expectedCash = round2(
    shift.opening_amount + cashSales + printingTotal + recargasGross - expenses
  );

  return {
    shift,
    cashSales: round2(cashSales),
    cardSales: round2(cardSales),
    printingTotal: round2(printingTotal),
    recargasGross: round2(recargasGross),
    expenses: round2(expenses),
    expectedCash,
  };
}

router.get('/cash-shifts/current', (req, res) => {
  const shift = db
    .prepare(`SELECT * FROM cash_shifts WHERE cashier_id = ? AND status = 'abierto' ORDER BY id DESC LIMIT 1`)
    .get(req.user.id);
  if (!shift) return res.json({ shift: null });
  res.json(computeShiftBreakdown(shift.id));
});

router.get('/cash-shifts', (req, res) => {
  const rows = db
    .prepare(
      `SELECT cs.*, u.full_name AS cashier_name
       FROM cash_shifts cs JOIN users u ON u.id = cs.cashier_id
       ORDER BY cs.opened_at DESC LIMIT 60`
    )
    .all();
  res.json(rows);
});

router.post('/cash-shifts/open', blockReadOnly, (req, res) => {
  const { opening_amount } = req.body || {};
  const existing = db
    .prepare(`SELECT * FROM cash_shifts WHERE cashier_id = ? AND status = 'abierto'`)
    .get(req.user.id);
  if (existing) return res.status(400).json({ error: 'Ya tienes un turno de caja abierto.' });

  const info = db
    .prepare(`INSERT INTO cash_shifts (cashier_id, opening_amount) VALUES (?, ?)`)
    .run(req.user.id, Number(opening_amount) || 0);
  res.status(201).json({ id: info.lastInsertRowid });
});

router.post('/cash-shifts/:id/close', blockReadOnly, (req, res) => {
  const { counted_amount } = req.body || {};
  const shift = db.prepare('SELECT * FROM cash_shifts WHERE id = ?').get(req.params.id);
  if (!shift) return res.status(404).json({ error: 'Turno no encontrado.' });
  if (shift.status !== 'abierto') return res.status(400).json({ error: 'Este turno ya esta cerrado.' });
  if (shift.cashier_id !== req.user.id && req.user.role !== 'admin' && req.user.role !== 'superadmin') {
    return res.status(403).json({ error: 'Solo puedes cerrar tu propio turno.' });
  }

  const breakdown = computeShiftBreakdown(shift.id);
  const counted = round2(Number(counted_amount));
  const difference = round2(counted - breakdown.expectedCash);

  db.prepare(
    `UPDATE cash_shifts SET closed_at = datetime('now'), closing_amount_system = ?, closing_amount_counted = ?, difference = ?, status = 'cerrado' WHERE id = ?`
  ).run(breakdown.expectedCash, counted, difference, shift.id);

  res.json({ ok: true, expectedCash: breakdown.expectedCash, counted, difference });
});

router.get('/cash-expenses', (req, res) => {
  const { shift_id } = req.query;
  let sql = `SELECT ce.*, u.full_name AS user_name FROM cash_expenses ce LEFT JOIN users u ON u.id = ce.user_id WHERE 1=1`;
  const params = [];
  if (shift_id) {
    sql += ' AND ce.shift_id = ?';
    params.push(shift_id);
  }
  sql += ' ORDER BY ce.date DESC LIMIT 100';
  res.json(db.prepare(sql).all(...params));
});

router.post('/cash-expenses', blockReadOnly, (req, res) => {
  const { description, category, amount } = req.body || {};
  const amt = Number(amount);
  if (!description || !amt || amt <= 0) {
    return res.status(400).json({ error: 'Descripcion y monto son requeridos.' });
  }
  const shift = db
    .prepare(`SELECT * FROM cash_shifts WHERE cashier_id = ? AND status = 'abierto'`)
    .get(req.user.id);
  if (!shift) return res.status(400).json({ error: 'Debes tener un turno de caja abierto.' });

  const info = db
    .prepare(
      `INSERT INTO cash_expenses (shift_id, description, category, amount, user_id) VALUES (?, ?, ?, ?, ?)`
    )
    .run(shift.id, description, category || 'operativo', amt, req.user.id);
  res.status(201).json({ id: info.lastInsertRowid });
});

module.exports = router;
