/* K@rin@ cyber — nucleo compartido del frontend */

const API_BASE = '/api';

const Auth = {
  getToken() { return localStorage.getItem('kc_token'); },
  getUser() {
    try { return JSON.parse(localStorage.getItem('kc_user') || 'null'); }
    catch { return null; }
  },
  setSession(token, user) {
    localStorage.setItem('kc_token', token);
    localStorage.setItem('kc_user', JSON.stringify(user));
  },
  clear() {
    localStorage.removeItem('kc_token');
    localStorage.removeItem('kc_user');
  },
  logout() {
    Auth.clear();
    window.location.href = '/index.html';
  },
};

async function api(path, { method = 'GET', body, isForm = false } = {}) {
  const headers = {};
  const token = Auth.getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;
  if (!isForm) headers['Content-Type'] = 'application/json';

  const res = await fetch(API_BASE + path, {
    method,
    headers,
    body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
  });

  if (res.status === 401) {
    Auth.clear();
    window.location.href = '/index.html';
    throw new Error('Sesion expirada');
  }

  const contentType = res.headers.get('content-type') || '';
  const isJson = contentType.includes('application/json');
  const data = isJson ? await res.json().catch(() => ({})) : await res.blob();

  if (!res.ok) {
    const message = (isJson && data && data.error) || 'Ocurrio un error inesperado.';
    throw new Error(message);
  }
  return data;
}

/* ---------------------------- Utilidades ---------------------------- */

function money(n) {
  const val = Number(n || 0);
  return 'C$ ' + val.toLocaleString('es-NI', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// SQLite's datetime('now') stores UTC without a timezone suffix (e.g. "2026-08-25 07:07:49"),
// while some rows are written from JS as full ISO strings with "Z". Normalize both to UTC
// before letting the browser convert to the visitor's local time zone.
function toDate(raw) {
  if (!raw) return null;
  let s = String(raw).replace(' ', 'T');
  if (!/[zZ]|[+-]\d{2}:?\d{2}$/.test(s)) s += 'Z';
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}

function fmtDateTime(iso) {
  const d = toDate(iso);
  if (!d) return '—';
  return d.toLocaleString('es-NI', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function fmtDate(iso) {
  const d = toDate(iso);
  if (!d) return '—';
  return d.toLocaleDateString('es-NI', { day: '2-digit', month: 'short', year: 'numeric' });
}

function initials(name) {
  if (!name) return '?';
  return name.split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
}

function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function toast(message, type = 'info') {
  let wrap = document.querySelector('.toast-wrap');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.className = 'toast-wrap';
    document.body.appendChild(wrap);
  }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  const icon = type === 'error' ? 'bi-exclamation-circle' : type === 'success' ? 'bi-check-circle' : 'bi-info-circle';
  el.innerHTML = `<i class="bi ${icon}"></i><span>${escapeHtml(message)}</span>`;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

function apiErrorToast(err) {
  toast(err.message || 'Ocurrio un error.', 'error');
}

/* ------------------------------- Shell ------------------------------- */

const NAV_ITEMS = [
  { section: 'General' },
  { href: '/dashboard.html', icon: 'bi-grid-1x2', label: 'Dashboard', roles: null },
  { section: 'Operacion diaria' },
  { href: '/pos.html', icon: 'bi-cart3', label: 'Punto de venta', roles: null },
  { href: '/impresiones.html', icon: 'bi-printer', label: 'Servicios de impresion', roles: null },
  { href: '/recargas.html', icon: 'bi-phone', label: 'Recargas', roles: null },
  { href: '/finanzas.html', icon: 'bi-cash-coin', label: 'Caja chica', roles: null },
  { section: 'Administracion' },
  { href: '/inventario.html', icon: 'bi-box-seam', label: 'Inventario y Kardex', roles: null },
  { href: '/reportes.html', icon: 'bi-bar-chart-line', label: 'Reportes', roles: null },
  { href: '/seguridad.html', icon: 'bi-shield-lock', label: 'Seguridad digital', roles: ['superadmin', 'admin', 'cajero'] },
  { href: '/usuarios.html', icon: 'bi-people', label: 'Usuarios', roles: ['superadmin', 'admin'] },
];

function requireAuthOrRedirect() {
  if (!Auth.getToken()) {
    window.location.href = '/index.html';
    return false;
  }
  return true;
}

function renderShell({ title, subtitle, active }) {
  const user = Auth.getUser() || {};
  const currentPath = window.location.pathname;

  const navHtml = NAV_ITEMS.map((item) => {
    if (item.section) return `<div class="nav-section">${item.section}</div>`;
    if (item.roles && !item.roles.includes(user.role)) return '';
    const isActive = currentPath.endsWith(item.href) ? 'active' : '';
    return `<a href="${item.href}" class="${isActive}"><i class="bi ${item.icon}"></i>${item.label}</a>`;
  }).join('');

  const shell = document.getElementById('app-shell');
  shell.innerHTML = `
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-brand">
        <div class="mark">K@</div>
        <div class="name">K@rin@ cyber<small>Sistema administrativo</small></div>
      </div>
      <nav class="sidebar-nav">${navHtml}</nav>
      <div class="sidebar-foot">
        <div class="user">
          <div class="avatar">${initials(user.full_name)}</div>
          <div class="who">
            <div class="n">${escapeHtml(user.full_name || '')}</div>
            <div class="r">${escapeHtml(user.role_label || '')}</div>
          </div>
        </div>
        <button class="logout-btn" onclick="Auth.logout()"><i class="bi bi-box-arrow-left"></i> Cerrar sesion</button>
      </div>
    </aside>
    <div class="main">
      <header class="topbar">
        <div class="flex items-center gap-3">
          <button class="menu-toggle" id="menuToggle"><i class="bi bi-list"></i></button>
          <div class="page-title">${escapeHtml(title)}${subtitle ? `<small>${escapeHtml(subtitle)}</small>` : ''}</div>
        </div>
        <div class="right">
          <span id="shiftBadge" class="shift-badge closed"><span class="dot"></span> Verificando turno...</span>
        </div>
      </header>
      <main class="content" id="page-content"></main>
    </div>
  `;

  const toggle = document.getElementById('menuToggle');
  if (toggle) {
    toggle.addEventListener('click', () => document.getElementById('sidebar').classList.toggle('open'));
  }

  if (['cajero', 'admin', 'superadmin'].includes(user.role)) {
    refreshShiftBadge();
  } else {
    document.getElementById('shiftBadge').style.display = 'none';
  }
}

async function refreshShiftBadge() {
  const badge = document.getElementById('shiftBadge');
  if (!badge) return;
  try {
    const data = await api('/finance/cash-shifts/current');
    if (data.shift) {
      badge.className = 'shift-badge open';
      badge.innerHTML = `<span class="dot"></span> Turno abierto · ${money(data.expectedCash)}`;
    } else {
      badge.className = 'shift-badge closed';
      badge.innerHTML = `<span class="dot"></span> Sin turno de caja abierto`;
    }
  } catch (err) {
    badge.style.display = 'none';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const y = document.querySelector('[data-year]');
  if (y) y.textContent = new Date().getFullYear();
});
